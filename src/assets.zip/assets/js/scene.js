export default class Scene {
    constructor() {
        this.instance = new THREE.Scene()
    }
}